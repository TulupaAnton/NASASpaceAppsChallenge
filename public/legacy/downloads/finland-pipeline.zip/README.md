# NASA Space Apps — Finland & Global Data Center Siting (v5.0)

Платформа оцінки та ранжування локацій у Фінляндії (та довільних координат `(lat, lon)` по всьому світу) для розміщення дата-центрів на основі **NASA POWER** (1984–2024), **DTU Global Wind Atlas v3.3 (100 м)**, **Copernicus DEM GLO-90** та **Copernicus GloFAS v4 (водні ресурси)**.

---

## Архітектура та формула оцінки (3 стовпи)

Для кожної локації розраховується індекс придатності `0–100` (Спосіб 2 — 3 рівні незалежних ресурсних категорій):

- **Клімат та охолодження (`climate`, 25%):** градусо-дні охолодження `DD10/рік` (`75%`) + пікова літня температура `T2M_MAX_AVG` (`25%`).
- **Відновлювана енергетика (`renewables`, 60%):** річна сонячна радіація GHI (`40%`) + вітровий потенціал на 100 м (`60%`, GWA v3.3 з фолбеком на фізичну екстраполяцію MERRA-2).
- **Водні ресурси (`water`, 15%):** відстань до найближчої водойми `water_distance_km` (`70%`) + локальний річковий стік `water_discharge_m3s` (`30%`).

---

## Готовність до роботи з коробки

19 офіційних регіонів Фінляндії вже зібрані та оброблені в репозиторії:
- [`output/frontend.json`](output/frontend.json) та [`output/frontend_merra2.json`](output/frontend_merra2.json) — готові рейтинги та графіки для UI;
- [`fetch_data/data/clean/`](fetch_data/data/clean/) — CSV/JSON таблиці та аналітичний звіт [`finland_datacenter_report.md`](fetch_data/data/clean/finland_datacenter_report.md);
- [`fetch_data/data/raw/`](fetch_data/data/raw/) — кеш сирих даних по 19 регіонах.

Кліки по нових точках світу оцінюються автономно за фіксованими фізичними межами (`PHYSICAL_REFERENCE_BOUNDS`) та автоматично кешуються у `fetch_data/data/raw/points_cache/` з просторовим допуском `±0.01°`.

---

## Швидкий старт

### 1. Бекенд API (`http://127.0.0.1:8000`)

#### Windows (PowerShell)
```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install --upgrade pip
.\.venv\Scripts\python.exe -m pip install -r requirements-api.txt
.\.venv\Scripts\python.exe api.py
```

#### macOS / Linux (bash / zsh)
```bash
python3 -m venv .venv
./.venv/bin/python -m pip install --upgrade pip
./.venv/bin/python -m pip install -r requirements-api.txt
./.venv/bin/python api.py
```

- Коренева перевірка: `http://127.0.0.1:8000/`
- Інтерактивна документація (Swagger UI): `http://127.0.0.1:8000/docs`

### 2. Фронтенд (React + Vite у `NasaChallange/`)

У другому вікні термінала:
```bash
cd NasaChallange
npm install
npm run dev
```

---

## Тестування та оновлення даних

```powershell
# Автотести
.\.venv\Scripts\python.exe -m pytest -q tests/

# Дозавантаження / перевірка сирих даних для 19 регіонів
.\.venv\Scripts\python.exe fetch_data/fetch_data.py

# Перегенерація CSV, звітів і output/frontend*.json
.\.venv\Scripts\python.exe fetch_data/process_data.py
```

---

## Повна специфікація для AI-агента та Frontend

Детальний технічний README для AI-агентів і фронтенд-розробників (карта файлів даних, JSON-схеми відповідей `/regions`, `/point`, `/points`, формули нормалізації та CLI) знаходиться у **[AGENT_FRONTEND_GUIDE.md](AGENT_FRONTEND_GUIDE.md)**.
